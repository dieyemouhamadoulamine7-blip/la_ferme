<?php
// Configuration générale du site

// URL de base du site (à adapter selon votre environnement)
define('BASE_URL', 'http://localhost/la_ferme/public/');

// Informations de la base de données
define('DB_HOST', 'localhost');
define('DB_NAME', 'la_ferme');
define('DB_USER', 'root');
define('DB_PASS', '');

// Options diverses
define('SITE_NAME', 'La Ferme - Boutique en ligne');


