<?php
require_once __DIR__ . '/../../includes/header.php';

if (!has_role('admin')) {
    redirect('login.php');
}

require_once __DIR__ . '/../../config/db.php';
$pdo = getPDO();

$action = $_GET['action'] ?? 'list';

/* =========================
   SUPPRESSION
========================= */
if ($action === 'delete' && isset($_GET['id'])) {
    $id = (int) $_GET['id'];
    $stmt = $pdo->prepare("DELETE FROM categories WHERE id = ?");
    $stmt->execute([$id]);
    redirect('admin/categories.php');
    exit;
}

/* =========================
   AJOUT
========================= */
if ($action === 'add' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $image = trim($_POST['image'] ?? '');
    
    if ($name) {
        $stmt = $pdo->prepare("INSERT INTO categories (name, description, image) VALUES (?, ?, ?)");
        $stmt->execute([
            $name,
            $description ?: null,
            $image ?: null
        ]);
        redirect('admin/categories.php');
        exit;
    }
}

/* =========================
   MODIFICATION
========================= */
if ($action === 'edit' && isset($_GET['id']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int) $_GET['id'];
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $image = trim($_POST['image'] ?? '');
    
    if ($name) {
        $stmt = $pdo->prepare("UPDATE categories SET name=?, description=?, image=? WHERE id=?");
        $stmt->execute([
            $name,
            $description ?: null,
            $image ?: null,
            $id
        ]);
        redirect('admin/categories.php');
        exit;
    }
}

/* =========================
   DONNÉES
========================= */
if ($action === 'edit' && isset($_GET['id'])) {
    $id = (int) $_GET['id'];
    $stmt = $pdo->prepare("SELECT * FROM categories WHERE id=?");
    $stmt->execute([$id]);
    $categoryToEdit = $stmt->fetch();
}

$stmt = $pdo->query("SELECT * FROM categories ORDER BY id DESC");
$categories = $stmt->fetchAll();
?>

<h1>Gestion des catégories</h1>

<?php if ($action === 'list'): ?>

    <p><a href="categories.php?action=add">➕ Ajouter une catégorie</a></p>

    <table class="table">
        <tr>
            <th>ID</th>
            <th>Nom</th>
            <th>Description</th>
            <th>Actions</th>
        </tr>

        <?php foreach ($categories as $cat): ?>
            <tr>
                <td><?= (int)$cat['id'] ?></td>
                <td><?= htmlspecialchars($cat['name']) ?></td>
                <td><?= htmlspecialchars(mb_substr($cat['description'] ?? '', 0, 50)) ?><?= mb_strlen($cat['description'] ?? '') > 50 ? '...' : '' ?></td>
                <td>
                    <a href="categories.php?action=edit&id=<?= $cat['id'] ?>">✏️ Modifier</a> |
                    <a href="categories.php?action=delete&id=<?= $cat['id'] ?>" onclick="return confirm('Supprimer cette catégorie ?')">🗑️ Supprimer</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>

<?php elseif ($action === 'add'): ?>

    <h2>Ajouter une catégorie</h2>
    <form method="post">
        <label>Nom * :</label>
        <input type="text" name="name" placeholder="Nom de la catégorie" required><br><br>
        
        <label>Description :</label>
        <textarea name="description" placeholder="Description de la catégorie" rows="4"></textarea><br><br>
        
        <label>Image (nom du fichier) :</label>
        <input type="text" name="image" placeholder="nom_image.jpg"><br><br>
        
        <button type="submit">Enregistrer</button>
        <a href="categories.php">Annuler</a>
    </form>

<?php elseif ($action === 'edit' && isset($categoryToEdit)): ?>

    <h2>Modifier la catégorie</h2>
    <form method="post">
        <label>Nom * :</label>
        <input type="text" name="name" value="<?= htmlspecialchars($categoryToEdit['name']) ?>" required><br><br>
        
        <label>Description :</label>
        <textarea name="description" placeholder="Description de la catégorie" rows="4"><?= htmlspecialchars($categoryToEdit['description'] ?? '') ?></textarea><br><br>
        
        <label>Image (nom du fichier) :</label>
        <input type="text" name="image" value="<?= htmlspecialchars($categoryToEdit['image'] ?? '') ?>" placeholder="nom_image.jpg"><br><br>
        
        <button type="submit">Modifier</button>
        <a href="categories.php">Annuler</a>
    </form>

<?php endif; ?>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
