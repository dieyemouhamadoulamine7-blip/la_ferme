<?php
require_once __DIR__ . '/../../includes/header.php';

if (!has_role('admin')) {
    redirect('login.php');
}

require_once __DIR__ . '/../../config/db.php';
$pdo = getPDO();

$action = $_GET['action'] ?? 'list';

/* =========================
   SUPPRESSION
========================= */
if ($action === 'delete' && isset($_GET['id'])) {
    $id = (int) $_GET['id'];
    $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
    $stmt->execute([$id]);
    redirect('admin/products.php');
    exit;
}

/* =========================
   AJOUT
========================= */
if ($action === 'add' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $category_id = isset($_POST['category_id']) ? (int)$_POST['category_id'] : 0;
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = isset($_POST['price']) ? (float)$_POST['price'] : 0;
    $stock = isset($_POST['stock']) ? (int)$_POST['stock'] : 0;
    $unit = trim($_POST['unit'] ?? 'unité');
    $image = trim($_POST['image'] ?? '');
    
    if ($category_id > 0 && $name && $price > 0) {
        $stmt = $pdo->prepare("INSERT INTO products (category_id, name, description, price, stock, unit, image) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $category_id,
            $name,
            $description,
            $price,
            $stock,
            $unit,
            $image
        ]);
        redirect('admin/products.php');
        exit;
    }
}

/* =========================
   MODIFICATION
========================= */
if ($action === 'edit' && isset($_GET['id']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int) $_GET['id'];
    $category_id = isset($_POST['category_id']) ? (int)$_POST['category_id'] : 0;
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = isset($_POST['price']) ? (float)$_POST['price'] : 0;
    $stock = isset($_POST['stock']) ? (int)$_POST['stock'] : 0;
    $unit = trim($_POST['unit'] ?? 'unité');
    $image = trim($_POST['image'] ?? '');
    
    if ($category_id > 0 && $name && $price > 0) {
        $stmt = $pdo->prepare("UPDATE products SET category_id=?, name=?, description=?, price=?, stock=?, unit=?, image=? WHERE id=?");
        $stmt->execute([
            $category_id,
            $name,
            $description,
            $price,
            $stock,
            $unit,
            $image,
            $id
        ]);
        redirect('admin/products.php');
        exit;
    }
}

/* =========================
   DONNÉES
========================= */
// Récupérer les catégories pour les formulaires
$categoriesStmt = $pdo->query("SELECT id, name FROM categories ORDER BY name");
$categories = $categoriesStmt->fetchAll();

if ($action === 'edit' && isset($_GET['id'])) {
    $id = (int) $_GET['id'];
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id=?");
    $stmt->execute([$id]);
    $productToEdit = $stmt->fetch();
}

$stmt = $pdo->query("SELECT p.*, c.name AS category_name FROM products p LEFT JOIN categories c ON c.id = p.category_id ORDER BY p.id DESC");
$products = $stmt->fetchAll();
?>

<h1>Gestion des produits</h1>

<?php if ($action === 'list'): ?>

    <p><a href="products.php?action=add">➕ Ajouter un produit</a></p>

    <table class="table">
        <tr>
            <th>ID</th>
            <th>Nom</th>
            <th>Catégorie</th>
            <th>Prix</th>
            <th>Stock</th>
            <th>Actions</th>
        </tr>

        <?php foreach ($products as $product): ?>
            <tr>
                <td><?= (int)$product['id'] ?></td>
                <td><?= htmlspecialchars($product['name']) ?></td>
                <td><?= htmlspecialchars($product['category_name'] ?? 'N/A') ?></td>
                <td><?= number_format($product['price'], 2, ',', ' ') ?> FCFA</td>
                <td><?= (int)$product['stock'] ?></td>
                <td>
                    <a href="products.php?action=edit&id=<?= $product['id'] ?>">✏️ Modifier</a> |
                    <a href="products.php?action=delete&id=<?= $product['id'] ?>" onclick="return confirm('Supprimer ce produit ?')">🗑️ Supprimer</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>

<?php elseif ($action === 'add'): ?>

    <h2>Ajouter un produit</h2>
    <form method="post">
        <label>Catégorie * :</label>
        <select name="category_id" required>
            <option value="">-- Sélectionner une catégorie --</option>
            <?php foreach ($categories as $cat): ?>
                <option value="<?= (int)$cat['id'] ?>"><?= htmlspecialchars($cat['name']) ?></option>
            <?php endforeach; ?>
        </select><br><br>
        
        <label>Nom * :</label>
        <input type="text" name="name" placeholder="Nom du produit" required><br><br>
        
        <label>Description :</label>
        <textarea name="description" placeholder="Description du produit" rows="4"></textarea><br><br>
        
        <label>Prix (FCFA) * :</label>
        <input type="number" name="price" step="0.01" placeholder="Prix" required><br><br>
        
        <label>Stock * :</label>
        <input type="number" name="stock" placeholder="Stock" min="0" required><br><br>
        
        <label>Unité :</label>
        <input type="text" name="unit" placeholder="unité, kg, sac, etc." value="unité"><br><br>
        
        <label>Image (nom du fichier) :</label>
        <input type="text" name="image" placeholder="nom_image.jpg"><br><br>
        
        <button type="submit">Enregistrer</button>
        <a href="products.php">Annuler</a>
    </form>

<?php elseif ($action === 'edit' && isset($productToEdit)): ?>

    <h2>Modifier le produit</h2>
    <form method="post">
        <label>Catégorie * :</label>
        <select name="category_id" required>
            <option value="">-- Sélectionner une catégorie --</option>
            <?php foreach ($categories as $cat): ?>
                <option value="<?= (int)$cat['id'] ?>" <?= ($productToEdit['category_id'] == $cat['id']) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($cat['name']) ?>
                </option>
            <?php endforeach; ?>
        </select><br><br>
        
        <label>Nom * :</label>
        <input type="text" name="name" value="<?= htmlspecialchars($productToEdit['name']) ?>" required><br><br>
        
        <label>Description :</label>
        <textarea name="description" placeholder="Description du produit" rows="4"><?= htmlspecialchars($productToEdit['description'] ?? '') ?></textarea><br><br>
        
        <label>Prix (FCFA) * :</label>
        <input type="number" name="price" step="0.01" value="<?= htmlspecialchars($productToEdit['price']) ?>" required><br><br>
        
        <label>Stock * :</label>
        <input type="number" name="stock" value="<?= htmlspecialchars($productToEdit['stock']) ?>" min="0" required><br><br>
        
        <label>Unité :</label>
        <input type="text" name="unit" value="<?= htmlspecialchars($productToEdit['unit'] ?? 'unité') ?>" placeholder="unité, kg, sac, etc."><br><br>
        
        <label>Image (nom du fichier) :</label>
        <input type="text" name="image" value="<?= htmlspecialchars($productToEdit['image'] ?? '') ?>" placeholder="nom_image.jpg"><br><br>
        
        <button type="submit">Modifier</button>
        <a href="products.php">Annuler</a>
    </form>

<?php endif; ?>

<?php
require_once __DIR__ . '/../../includes/footer.php';
?>
