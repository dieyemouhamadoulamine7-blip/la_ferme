<?php
require_once __DIR__ . '/../../includes/header.php';

if (!has_role('admin')) {
    redirect('login.php');
}

require_once __DIR__ . '/../../config/db.php';
$pdo = getPDO();

$action = $_GET['action'] ?? 'list';

/* =========================
   CHANGER ROLE
========================= */
if ($action === 'role' && isset($_GET['id']) && isset($_GET['role'])) {
    $id = (int)$_GET['id'];
    $role = $_GET['role'];
    
    // Valider que le rôle est dans l'ENUM
    $validRoles = ['visiteur', 'client', 'admin'];
    if (in_array($role, $validRoles)) {
        $stmt = $pdo->prepare("UPDATE users SET role=? WHERE id=?");
        $stmt->execute([$role, $id]);
        redirect('admin/users.php');
        exit;
    }
}

/* =========================
   SUPPRIMER USER
========================= */
if ($action === 'delete' && isset($_GET['id'])) {
    $stmt = $pdo->prepare("DELETE FROM users WHERE id=?");
    $stmt->execute([ (int)$_GET['id'] ]);
    redirect('admin/users.php');
    exit;
}

/* =========================
   LISTE
========================= */
$stmt = $pdo->query("SELECT id, name, email, role, created_at FROM users ORDER BY id DESC");
$users = $stmt->fetchAll();
?>

<h1>Gestion des utilisateurs</h1>

<table class="table">
    <tr>
        <th>ID</th>
        <th>Nom</th>
        <th>Email</th>
        <th>Rôle</th>
        <th>Date</th>
        <th>Actions</th>
    </tr>

<?php foreach ($users as $u): ?>
<tr>
    <td><?= (int)$u['id'] ?></td>
    <td><?= htmlspecialchars($u['name']) ?></td>
    <td><?= htmlspecialchars($u['email']) ?></td>
    <td><?= htmlspecialchars($u['role']) ?></td>
    <td><?= htmlspecialchars($u['created_at']) ?></td>
    <td>
        <a href="users.php?action=role&id=<?= $u['id'] ?>&role=admin">👑 Admin</a> |
        <a href="users.php?action=role&id=<?= $u['id'] ?>&role=client">👤 Client</a> |
        <a href="users.php?action=role&id=<?= $u['id'] ?>&role=visiteur">👁️ Visiteur</a> |
        <a href="users.php?action=delete&id=<?= $u['id'] ?>" onclick="return confirm('Supprimer cet utilisateur ?')">🗑️ Supprimer</a>
    </td>
</tr>
<?php endforeach; ?>

</table>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
