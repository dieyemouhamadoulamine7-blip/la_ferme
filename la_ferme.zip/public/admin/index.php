<?php
require_once __DIR__ . '/../../includes/header.php';

if (!has_role('admin')) {
    redirect('login.php');
}
?>

<h1>Administration</h1>

<ul>
    <li><a href="products.php">Gérer les produits</a></li>
    <li><a href="categories.php">Gérer les catégories</a></li>
    <li><a href="orders.php">Gérer les commandes</a></li>
    <li><a href="users.php">Gérer les utilisateurs</a></li>
</ul>

<?php
require_once __DIR__ . '/../../includes/footer.php';
?>


