<?php
require_once __DIR__ . '/../../includes/header.php';

if (!has_role('admin')) {
    redirect('login.php');
}

require_once __DIR__ . '/../../config/db.php';
$pdo = getPDO();

$action = $_GET['action'] ?? 'list';

/* =========================
   CHANGER STATUT
========================= */
if ($action === 'status' && isset($_GET['id']) && isset($_GET['status'])) {
    $id = (int)$_GET['id'];
    $status = $_GET['status'];
    
    // Valider que le statut est dans l'ENUM
    $validStatuses = ['en_attente', 'en_cours', 'expediee', 'livree', 'annulee'];
    if (in_array($status, $validStatuses)) {
        $stmt = $pdo->prepare("UPDATE orders SET status=? WHERE id=?");
        $stmt->execute([$status, $id]);
        redirect('admin/orders.php');
        exit;
    }
}

/* =========================
   LISTE COMMANDES
========================= */
$stmt = $pdo->query("
    SELECT o.*, u.name AS user_name
    FROM orders o
    LEFT JOIN users u ON u.id = o.user_id
    ORDER BY o.created_at DESC
");
$orders = $stmt->fetchAll();
?>

<h1>Gestion des commandes</h1>

<table class="table">
    <tr>
        <th>ID</th>
        <th>Client</th>
        <th>Total</th>
        <th>Statut</th>
        <th>Date</th>
        <th>Actions</th>
    </tr>

    <?php foreach ($orders as $o): ?>
        <tr>
            <td><?= (int)$o['id'] ?></td>
            <td><?= htmlspecialchars($o['user_name'] ?? ($o['customer_name'] ?? 'Invité')) ?></td>
            <td><?= number_format($o['total_amount'] ?? $o['total'] ?? 0, 0, ',', ' ') ?> FCFA</td>
            <td><?= htmlspecialchars($o['status']) ?></td>
            <td><?= htmlspecialchars($o['created_at']) ?></td>
            <td>
                <a href="orders.php?action=status&id=<?= $o['id'] ?>&status=en_attente">⏳ En attente</a> |
                <a href="orders.php?action=status&id=<?= $o['id'] ?>&status=en_cours">🔄 En cours</a> |
                <a href="orders.php?action=status&id=<?= $o['id'] ?>&status=expediee">📦 Expédiée</a> |
                <a href="orders.php?action=status&id=<?= $o['id'] ?>&status=livree">✅ Livrée</a> |
                <a href="orders.php?action=status&id=<?= $o['id'] ?>&status=annulee">❌ Annulée</a>
            </td>
        </tr>
    <?php endforeach; ?>
</table>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
