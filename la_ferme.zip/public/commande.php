<?php
require_once __DIR__ . '/../includes/header.php';

if (!is_logged_in()) {
    // On force la connexion pour passer commande
    redirect('login.php');
}

$pdo = getPDO();
$cart = get_cart();

if (empty($cart)) {
    echo '<p>Votre panier est vide.</p>';
    echo '<p><a href="boutique.php" class="btn-secondary">Retour à la boutique</a></p>';
    require_once __DIR__ . '/../includes/footer.php';
    exit;
}

// Récupération des produits du panier
$ids = array_keys($cart);
$placeholders = implode(',', array_fill(0, count($ids), '?'));
$stmt = $pdo->prepare("SELECT * FROM products WHERE id IN ($placeholders)");
$stmt->execute($ids);
$products = $stmt->fetchAll();

$total = 0;
foreach ($products as &$product) {
    $qty = $cart[$product['id']]['quantity'] ?? 0;
    $product['quantity'] = $qty;
    $product['line_total'] = $qty * $product['price'];
    $total += $product['line_total'];
}

$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Dans un vrai site, on aurait ici la gestion du paiement.
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare('INSERT INTO orders (user_id, total_amount, status, created_at) VALUES (:user_id, :total_amount, :status, NOW())');
        $stmt->execute([
            'user_id' => $_SESSION['user']['id'],
            'total_amount' => $total,
            'status' => 'en_attente',
        ]);

        $order_id = $pdo->lastInsertId();

        $stmtItem = $pdo->prepare('INSERT INTO order_items (order_id, product_id, quantity, unit_price, total_price) 
                                   VALUES (:order_id, :product_id, :quantity, :unit_price, :total_price)');

        foreach ($products as $product) {
            $stmtItem->execute([
                'order_id' => $order_id,
                'product_id' => $product['id'],
                'quantity' => $product['quantity'],
                'unit_price' => $product['price'],
                'total_price' => $product['line_total'],
            ]);
        }

        $pdo->commit();
        clear_cart();
        $success = true;
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = "Une erreur est survenue lors de la validation de la commande.";
    }
}
?>

<h1>Validation de la commande</h1>

<?php if (!empty($success)): ?>
    <p class="alert success">Merci, votre commande a été enregistrée !</p>
    <p><a href="compte.php" class="btn-primary">Voir mes commandes</a></p>
<?php else: ?>
    <?php if (!empty($error)): ?>
        <p class="alert error"><?php echo htmlspecialchars($error); ?></p>
    <?php endif; ?>

    <h2>Récapitulatif</h2>
    <table class="table">
        <thead>
        <tr>
            <th>Produit</th>
            <th>Prix</th>
            <th>Quantité</th>
            <th>Total</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($products as $product): ?>
            <tr>
                <td><?php echo htmlspecialchars($product['name']); ?></td>
                <td><?php echo number_format($product['price'], 2, ',', ' '); ?> €</td>
                <td><?php echo (int)$product['quantity']; ?></td>
                <td><?php echo number_format($product['line_total'], 2, ',', ' '); ?> €</td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <p><strong>Total :</strong> <?php echo number_format($total, 2, ',', ' '); ?> €</p>

    <form method="post">
        <p>Pour ce projet pédagogique, nous simulons la validation sans paiement en ligne.</p>
        <button type="submit" class="btn-primary">Confirmer ma commande</button>
    </form>
<?php endif; ?>

<?php
require_once __DIR__ . '/../includes/footer.php';
?>


