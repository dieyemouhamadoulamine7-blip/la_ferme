    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>la ferme</h3>
                    <p>Votre partenaire de confiance pour tous vos besoins avicoles.</p>
                </div>
                <div class="footer-section">
                    <h3>Contact</h3>
                    <p>Téléphone: +221 33 890 20 20</p>
                    <p>Email: laferme@gmail.com</p>
                </div>
                <div class="footer-section">
                    <h3>Liens rapides</h3>
                    <a href="index.php">Accueil</a>
                    <a href="products.php">Produits</a>
                    <a href="cart.php">Panier</a>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> La Ferme Avicole. Tous droits réservés.</p>
            </div>
        </div>
    </footer>

    <?php if (isset($scripts)): ?>
        <?php foreach ($scripts as $script): ?>
            <script src="<?php echo $script; ?>"></script>
        <?php endforeach; ?>
    <?php else: ?>
        <script src="assets/js/main.js"></script>
    <?php endif; ?>
</body>
</html>


